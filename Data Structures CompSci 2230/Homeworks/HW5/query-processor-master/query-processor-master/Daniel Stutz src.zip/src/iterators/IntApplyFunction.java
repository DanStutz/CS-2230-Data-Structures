package iterators;

// Interface for classes to define a function that takes an int and produces and int
public interface IntApplyFunction {

    public int apply(int x);
}
