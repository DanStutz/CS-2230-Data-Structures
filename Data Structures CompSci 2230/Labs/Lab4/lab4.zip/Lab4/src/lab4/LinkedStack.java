package lab4;

class LinkedStack implements Stack {
	// reference to the top of the Stack
	private ListNode top;
    
    public LinkedStack() {
        // your constructor code
    }
    

    // your methods go here
    
    

	// you must use ListNode objects in LinkedStack
	private class ListNode {
			public Object data;
			public ListNode next;

			public ListNode(Object d) {
					this.data = d;
					this.next = null;
			}
	}

}
