package lab4;

class LinkedQueue implements Queue {
	// your fields go here
    
    public LinkedQueue() {
        // your constructor code
    }
    

    // your methods go here
    
    

	// you must use ListNode objects in LinkedQueue
	private class ListNode {
			public Object data;
			public ListNode next;

			public ListNode(Object d) {
					this.data = d;
					this.next = null;
			}
			
	}

}
